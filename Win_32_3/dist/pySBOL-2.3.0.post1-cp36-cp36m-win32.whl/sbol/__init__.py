from __future__ import absolute_import

__version__ = '2.3.0b'

from sbol.libsbol import *
import sbol.unit_tests

pySBOL
=======================

**pySBOL** is a SWIG-Python wrapper around [libSBOL](https://github.com/SynBioDex/libSBOL), a module for
reading, writing, and constructing genetic designs according to the standardized specifications of 
the [Synthetic Biology Open Language (SBOL)](http://www.sbolstandard.org/).  


